require("dotenv").config();
const express = require("express");
const path = require("path");
const helmet = require("helmet");
const cookieParser = require("cookie-parser");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const crypto = require("crypto");
const db = require("./db");

const app = express();
const PORT = process.env.PORT || 3000;
const SECRET = process.env.JWT_SECRET || "dev-only-change-this-secret";

app.use(helmet({contentSecurityPolicy:false}));
app.use(express.json({limit:"100kb"}));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, "..", "public")));

function tokenFor(user){
  return jwt.sign({id:user.id,email:user.email,role:user.role}, SECRET, {expiresIn:"2h"});
}
function auth(req,res,next){
  const token = req.cookies.session || (req.headers.authorization||"").replace(/^Bearer\s+/,"");
  if(!token) return res.status(401).json({error:"Authentication required"});
  try { req.user = jwt.verify(token, SECRET); next(); }
  catch { return res.status(401).json({error:"Session expired or invalid"}); }
}
function admin(req,res,next){
  if(req.user.role !== "admin") return res.status(403).json({error:"Admin access required"});
  next();
}
function appNo(){ return "APP-"+Date.now().toString(36).toUpperCase()+"-"+crypto.randomBytes(2).toString("hex").toUpperCase(); }
function payRef(){ return "PAY-"+Date.now().toString(36).toUpperCase()+"-"+crypto.randomBytes(3).toString("hex").toUpperCase(); }

app.post("/api/auth/register", async (req,res)=>{
  const {full_name,email,phone,password} = req.body || {};
  if(!full_name || !email || !password || password.length < 8) return res.status(400).json({error:"Full name, email and password (8+ characters) are required"});
  const normalized=email.trim().toLowerCase();
  try{
    const hash=await bcrypt.hash(password,12);
    const info=db.prepare("INSERT INTO users(full_name,email,phone,password_hash) VALUES(?,?,?,?)").run(full_name.trim(),normalized,phone||"",hash);
    const user={id:info.lastInsertRowid,email:normalized,role:"citizen"};
    res.cookie("session",tokenFor(user),{httpOnly:true,sameSite:"lax",secure:process.env.NODE_ENV==="production",maxAge:7200000});
    res.status(201).json({user:{id:user.id,email:user.email,full_name:full_name.trim(),role:user.role}});
  }catch(e){ res.status(409).json({error:"An account with that email already exists"}); }
});

app.post("/api/auth/login", async (req,res)=>{
  const {email,password}=req.body||{};
  const user=db.prepare("SELECT * FROM users WHERE email=?").get((email||"").trim().toLowerCase());
  if(!user || !(await bcrypt.compare(password||"",user.password_hash))) return res.status(401).json({error:"Invalid email or password"});
  res.cookie("session",tokenFor(user),{httpOnly:true,sameSite:"lax",secure:process.env.NODE_ENV==="production",maxAge:7200000});
  res.json({user:{id:user.id,email:user.email,full_name:user.full_name,phone:user.phone,role:user.role}});
});

app.post("/api/auth/logout",(req,res)=>{res.clearCookie("session");res.json({ok:true});});
app.get("/api/auth/me",auth,(req,res)=>{
  const u=db.prepare("SELECT id,full_name,email,phone,role,created_at FROM users WHERE id=?").get(req.user.id);
  res.json({user:u});
});

app.get("/api/services",(req,res)=>{
  res.json({services:[
    {id:"business-registration",name:"Business Registration",description:"Register a business and access related services."},
    {id:"good-conduct",name:"Certificate of Good Conduct",description:"Start an application and review requirements."},
    {id:"passport",name:"Passport Services",description:"Access passport application information."},
    {id:"driving-licence",name:"Driving Licence",description:"Find licensing services and application information."},
    {id:"birth-certificate",name:"Birth Certificate",description:"Access civil registration information."},
    {id:"land-services",name:"Land Services",description:"Find land-related public services."},
    {id:"tax-services",name:"Tax Services",description:"Access tax-related service information."},
    {id:"police-clearance",name:"Police Clearance",description:"Review clearance requirements."}
  ]});
});

app.post("/api/applications",auth,(req,res)=>{
  const {service,details}=req.body||{};
  if(!service) return res.status(400).json({error:"Service is required"});
  const number=appNo();
  const info=db.prepare("INSERT INTO applications(user_id,service,application_number,details) VALUES(?,?,?,?)")
    .run(req.user.id,service,number,details||"");
  const row=db.prepare("SELECT * FROM applications WHERE id=?").get(info.lastInsertRowid);
  res.status(201).json({application:row});
});

app.get("/api/applications",auth,(req,res)=>{
  const rows=req.user.role==="admin"
    ? db.prepare(`SELECT a.*,u.full_name,u.email FROM applications a JOIN users u ON u.id=a.user_id ORDER BY a.id DESC`).all()
    : db.prepare("SELECT * FROM applications WHERE user_id=? ORDER BY id DESC").all(req.user.id);
  res.json({applications:rows});
});

app.patch("/api/applications/:id",auth,admin,(req,res)=>{
  const {status}=req.body||{};
  const allowed=["Submitted","Processing","Approved","Rejected","Completed"];
  if(!allowed.includes(status)) return res.status(400).json({error:"Invalid status"});
  const info=db.prepare("UPDATE applications SET status=?,updated_at=CURRENT_TIMESTAMP WHERE id=?").run(status,req.params.id);
  if(!info.changes) return res.status(404).json({error:"Application not found"});
  res.json({ok:true});
});

app.post("/api/payments",auth,(req,res)=>{
  const {application_id,amount}=req.body||{};
  const a=db.prepare("SELECT * FROM applications WHERE id=? AND user_id=?").get(application_id,req.user.id);
  if(!a) return res.status(404).json({error:"Application not found"});
  if(!Number.isFinite(Number(amount)) || Number(amount)<=0) return res.status(400).json({error:"Valid amount is required"});
  const reference=payRef();
  const info=db.prepare("INSERT INTO payments(application_id,amount,reference,status) VALUES(?,?,?,?)")
    .run(application_id,Number(amount),reference,"Pending");
  res.status(201).json({payment:{id:info.lastInsertRowid,reference,status:"Pending",amount:Number(amount)}});
});

app.get("/api/payments",auth,(req,res)=>{
  const rows=req.user.role==="admin"
    ? db.prepare(`SELECT p.*,a.application_number,u.full_name FROM payments p JOIN applications a ON a.id=p.application_id JOIN users u ON u.id=a.user_id ORDER BY p.id DESC`).all()
    : db.prepare(`SELECT p.*,a.application_number FROM payments p JOIN applications a ON a.id=p.application_id WHERE a.user_id=? ORDER BY p.id DESC`).all(req.user.id);
  res.json({payments:rows});
});

/* Demo payment confirmation. Replace this endpoint with a real payment provider webhook. */
app.post("/api/payments/:id/confirm",auth,admin,(req,res)=>{
  const info=db.prepare("UPDATE payments SET status='Paid',paid_at=CURRENT_TIMESTAMP WHERE id=?").run(req.params.id);
  if(!info.changes) return res.status(404).json({error:"Payment not found"});
  res.json({ok:true});
});

app.get("/api/admin/users",auth,admin,(req,res)=>{
  res.json({users:db.prepare("SELECT id,full_name,email,phone,role,created_at FROM users ORDER BY id DESC").all()});
});

app.get("*",(req,res)=>res.sendFile(path.join(__dirname,"..","public","index.html")));
app.listen(PORT,()=>console.log(`Civic Services running at http://localhost:${PORT}`));
