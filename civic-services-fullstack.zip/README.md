# Civic Services Portal — Full Stack Demo

Standalone civic-services portal inspired by common government-service UX patterns.
It is NOT the official eCitizen website.

## Requirements
- Node.js 18+
- npm

## Run
1. Copy `.env.example` to `.env`.
2. Set a strong `JWT_SECRET`.
3. Run `npm install`.
4. Run `npm start`.
5. Open `http://localhost:3000`.

The SQLite database is created automatically as `civic-services.db`.

## Features
- Citizen registration and login
- HTTP-only session cookie using JWT
- Password hashing with bcrypt
- Service catalogue
- Application submission and tracking
- Payment records with demo confirmation endpoint
- Admin application status management
- Admin user listing endpoint
- SQLite persistence

## Admin
For a real deployment, create an administrator securely rather than shipping an admin password. The API uses `role=admin`.

## Production checklist
Use HTTPS, a managed PostgreSQL database, secrets manager, CSRF protection appropriate to the auth design, rate limiting, audit logs, backups, monitoring, and a real payment provider/webhook. Do not collect real government credentials in this prototype.
